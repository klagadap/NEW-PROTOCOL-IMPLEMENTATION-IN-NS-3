#include <algorithm>
#include "pnet-channel.h"
#include "ns3/mobility-module.h"
#include "ns3/my-pnet-phy.h"
#include "pnet-phy.h"
#include "pnet-net-device.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/node.h"
#include "ns3/log.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("PnetChannel");

NS_OBJECT_ENSURE_REGISTERED (PnetChannel);

TypeId 
PnetChannel::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::PnetChannel")
    .SetParent<Channel> ()
    .AddConstructor<PnetChannel> ()
    .AddAttribute ("Delay", "Transmission delay through the channel",
                   TimeValue (MilliSeconds (2)),
                   MakeTimeAccessor (&PnetChannel::m_delay),
                   MakeTimeChecker ())
  ;
  return tid;
}

PnetChannel::PnetChannel ()
{
  NS_LOG_FUNCTION (this);
}

void
PnetChannel::Send (Ptr<PnetPhy> sender, Ptr<Packet> p, Time duration)
{
  Ptr<MobilityModel> Sender= sender->GetDevice()->GetNode()->GetObject<MobilityModel>();//set the pointer to the mobility model
  NS_LOG_FUNCTION (this );
  uint32_t j = 0;
  for (PhyList::const_iterator i = m_phyList.begin (); i != m_phyList.end (); i++,j++)
    {
      NS_LOG_INFO ("value of j: "<<j);
      Ptr<PnetPhy> tmp = *i;
      if (tmp != sender)
        {                         Ptr<MobilityModel> receiver= tmp->GetDevice()->GetNode()->GetObject<MobilityModel>();// Also set the receiver pointer to mobility model
				  NS_LOG_INFO ("node id"<<tmp->GetDevice()->GetNode ()->GetId());
                                  d= Sender->GetDistanceFrom(receiver);//obtained the distance b/w nodes 
                                  t1=Seconds(d/300000000); // obtained the propagation delay             
				  Simulator::ScheduleWithContext (tmp->GetDevice()->GetNode ()->GetId (), m_delay+t1,
				                                  &PnetChannel::Receive, this, j, p->Copy (), duration);//added prop. delay as t1 to m-delay
				  NS_LOG_INFO ("Propagation delay from the sender"<<j+1<<"th node is"<<t1<<"ns with given distance"<<d<<"m");
        }//displayed the resulting prop. delay using NS_LOG_INFO
    }
}

void
PnetChannel::Receive (uint32_t i, Ptr<Packet> packet, Time rxDuration) const
{
  m_phyList[i]->StartReceivePacket (packet, rxDuration);
}

void
PnetChannel::Add (Ptr<PnetPhy> phy)
{
  NS_LOG_FUNCTION (this << phy);
  m_phyList.push_back (phy);
}

uint32_t
PnetChannel::GetNDevices (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phyList.size ();
}

Ptr<NetDevice>
PnetChannel::GetDevice (uint32_t i) const
{
  NS_LOG_FUNCTION (this << i);
  return m_phyList[i]->GetDevice ()->GetObject<NetDevice> ();
}


} // namespace ns3
